The demos are for illustration purposes only, and not production ready. Hammer.js is not a component library.
